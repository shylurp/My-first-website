import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControlLabel,
  IconButton,
  Stack,
  TextField,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { useState } from "react";
import "./Modal.css";

const Modal = () => {
  const [open, setOpen] = useState(false);
  const functionopenpopup = () => {
    setOpen(true);
  };
  const closepopup = () => {
    setOpen(false);
  };
  return (
    <div style={{ textAlign: "center" }}>
      <h1 id="modal-title" className="modal__title">
        Join with me
      </h1>
      <Button
        className="modal__button"
        onClick={functionopenpopup}
        color="primary"
        variant="contained"
      >
        Join with me
      </Button>

      <Dialog open={open} onClose={closepopup} fullWidth maxWidth="sm">
        <DialogTitle>
          <IconButton onClick={closepopup} style={{ float: "right" }}>
            <CloseIcon color="primary"></CloseIcon>
          </IconButton>{" "}
        </DialogTitle>

        <DialogContent>
          <Stack spacing={2} margin={2}>
            <TextField variant="outlined" label="Name"></TextField>
            <TextField variant="outlined" label="Email"></TextField>
            <TextField variant="outlined" label="Phone"></TextField>

            <Button color="primary" variant="contained">
              Join
            </Button>
          </Stack>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Modal;
