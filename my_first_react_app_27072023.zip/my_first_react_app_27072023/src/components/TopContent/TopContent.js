import React from "react";
import { Link } from "react-scroll";
import "./TopContent.css";

const TopContent = ({selected, setSelected }) => {
  return (
    <div className="topContent">
      <div className="topContent__container">
        <h1>Mrs.Shylajadevi Arunprasath</h1>
        <p>A Professional Web and App Developer</p>
        <a
          className="downloadCv"
          href="../../Assets/Shylajadevi_Arun_CV_ITonline.pdf"
          download="Shylajadevi_Arun_CV_ITonline.pdf"
          onClick={() => setSelected("downloadCV")}
        >
          <button className="topContent__downloadButton">Download CV</button>
        </a>
        <Link to="projects" smooth={true} duration={500}>
          <button className="topContent__workButton">My Work</button>
        </Link>
      </div>
    </div>
  );
};

export default TopContent;
