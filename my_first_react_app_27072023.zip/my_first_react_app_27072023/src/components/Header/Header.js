import React from "react";
import "./Header.css";
import CloseIcon from "@mui/icons-material/Close";
import { useState } from "react";
import { Link } from "react-scroll";
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  FormControlLabel,
  IconButton,
  Stack,
  TextField,
} from "@mui/material";

const Header = ({ selected, setSelected, setOpen }) => {
  // const [open, setOpen] = useState(false);
  // const functionopenpopup = () => {
  //   setOpen(true);
  // };
  // const closepopup = () => {
  //   setOpen(false);
  // };
  return (
    <div className="header">
      <div className="header__left">
        <h1>
          Develop<span>er</span>
        </h1>
      </div>
      <div className="header__right">
        <Link to="about" smooth={true} duration={500}>
          <h4
            className={
              selected === "about" ? "header__right--active" : undefined
            }
            onClick={() => setSelected("about")}
          >
            About Me
          </h4>
        </Link>
        <Link to="skills" smooth={true} duration={500}>
          <h4
            className={
              selected === "skills" ? "header__right--active" : undefined
            }
            onClick={() => setSelected("skills")}
          >
            Skills
          </h4>
        </Link>
        <Link to="projects" smooth={true} duration={500}>
          <h4
            className={
              selected === "projects" ? "header__right--active" : undefined
            }
            onClick={() => setSelected("projects")}
          >
            Projects
          </h4>
        </Link>

        <Link to="contact" smooth={true} duration={500}>
          <h4
            className={
              selected === "contact" ? "header__right--active" : undefined
            }
            onClick={() => setSelected("contact")}
          >
            Contact
          </h4>
        </Link>

        <h4 className="header__rightButton" onClick={() => setOpen(true)}></h4>
        <Button
          onClick={functionopenpopup}
          // variant="contained"
        >
          Join with me
        </Button>
      </div>
    </div>
  );
};

const Modal = () => {
  const [open, setOpen] = useState(false);
  const functionopenpopup = () => {
    setOpen(true);
  };
  const closepopup = () => {
    setOpen(false);
  };
  return (
    <div style={{ textAlign: "center" }}>
      <h1 id="modal-title" className="modal__title">
        Join with me
      </h1>
      <Button
        className="modal__button"
        onClick={functionopenpopup}
        color="primary"
        variant="contained"
      >
        Join with me
      </Button>

      <Dialog open={open} onClose={closepopup} fullWidth maxWidth="sm">
        <DialogTitle>
          <IconButton onClick={closepopup} style={{ float: "right" }}>
            <CloseIcon color="primary"></CloseIcon>
          </IconButton>{" "}
        </DialogTitle>

        <DialogContent>
          <Stack spacing={2} margin={2}>
            <TextField variant="outlined" label="Name"></TextField>
            <TextField variant="outlined" label="Email"></TextField>
            <TextField variant="outlined" label="Phone"></TextField>

            <Button color="primary" variant="contained">
              Join
            </Button>
            <h4
              className="header__rightButton"
              onClick={() => setOpen(true)}
            ></h4>
            <Button
              onClick={functionopenpopup}

              // variant="contained"
            >
              Join with me
            </Button>
          </Stack>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Header;
