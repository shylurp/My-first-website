import React from "react";
import FormJoin from "FormJoin";

const Form = () => {
  return (
    <div>
      <FormJoin />
    </div>
  );
};

export default Form;
