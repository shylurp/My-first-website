import React from "react";

const FormJoin = () => {
  return (
    <div>
      <h1>FormJoin</h1>
    </div>
  );
};

export default FormJoin;
